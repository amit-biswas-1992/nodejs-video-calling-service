import { createServer } from "./server.js";

createServer();
